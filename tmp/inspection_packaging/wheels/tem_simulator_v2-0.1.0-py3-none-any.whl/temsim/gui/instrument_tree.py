"""Filtered, TOML-backed instrument navigation trees."""

from __future__ import annotations

from dataclasses import dataclass

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QTreeWidget, QTreeWidgetItem

from temsim.component_keys import (
    ENERGY_FILTER_ENTRANCE_APERTURE,
    FIXED_APERTURE_KEYS,
    NANOPULSER_APERTURE,
    ENERGY_FILTER_INTERNAL_KEYS,
    IMAGE_CORRECTOR_KEYS,
    PROBE_CORRECTOR_KEYS,
)


OPTICAL_FILTERS = (
    ("all", "All optical"),
    ("electron_source", "Electron source"),
    ("lens", "Lenses"),
    ("deflector", "Deflectors"),
    ("aperture", "Apertures"),
    ("stigmator", "Stigmators"),
    ("corrector", "Correctors"),
    ("other", "Detectors"),
)
OPTICAL_CATEGORY_LABELS = {
    "electron_source": "Electron source",
    "lens": "Lenses",
    "deflector": "Deflectors",
    "aperture": "Apertures",
    "stigmator": "Stigmators",
    "corrector": "Correctors",
    "other": "Detectors",
}
OPTICAL_CATEGORY_ORDER = tuple(OPTICAL_CATEGORY_LABELS)
CORRECTOR_KEYS = frozenset((*PROBE_CORRECTOR_KEYS, *IMAGE_CORRECTOR_KEYS))
GLOBAL_RUNTIME_KEYS = ("simulation",)
ELECTRON_SOURCE_RUNTIME_KEY = "electron_gun"
ELECTRON_SOURCE_RUNTIME_LABEL = "Gun ray tracing"
CENTRAL_WORKSPACE_KEYS = frozenset({
    "sample",
    "energy_filter",
    *ENERGY_FILTER_INTERNAL_KEYS,
}) - {ENERGY_FILTER_ENTRANCE_APERTURE}


@dataclass(frozen=True, slots=True)
class TreeSelection:
    key: str
    label: str
    module_path: str | None
    is_module: bool = False


class InstrumentTree(QTreeWidget):
    component_selected = Signal(object)
    component_activated = Signal(object)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("instrumentTree")
        self.setHeaderLabel("Active TEM assembly")
        self.setAlternatingRowColors(True)
        self.setMinimumWidth(285)
        self.currentItemChanged.connect(self._emit_current_item)
        self.itemDoubleClicked.connect(self._emit_activated_item)

    @staticmethod
    def _selection_item(label: str, selection: TreeSelection):
        item = QTreeWidgetItem([label])
        if not selection.is_module:
            item.setToolTip(0, selection.key)
        item.setData(0, Qt.ItemDataRole.UserRole, selection)
        return item

    @staticmethod
    def _module_paths(assembly) -> dict[str, str]:
        selected_paths = dict(assembly.selected_module_paths)
        return {
            module.key: selected_paths[module.type]
            for module in assembly.modules
        }

    @staticmethod
    def _is_optical_part(part, runtime_targets) -> bool:
        return (
            part.key not in CENTRAL_WORKSPACE_KEYS
            # NanoPulser owns its stop geometry; edit the original TOML,
            # never a temporary copy returned by nanopulser.aperture.
            and (part.key in runtime_targets or part.key == NANOPULSER_APERTURE)
            and not bool(part.data.get("mechanical_only", False))
        )

    @staticmethod
    def optical_category(
        part, runtime_target=None, *, module_type: str | None = None
    ) -> str:
        key = str(part.key)
        if "aperture" in key:
            return "aperture"
        if module_type == "gun":
            return "electron_source"
        if key == "energy_filter" or key in ENERGY_FILTER_INTERNAL_KEYS:
            return "energy_filter"
        if key in CORRECTOR_KEYS:
            return "corrector"
        if "stigmator" in key:
            return "stigmator"
        if "deflector" in key:
            return "deflector"
        obj = getattr(runtime_target, "obj", None)
        if "lens" in key or (obj is not None and hasattr(obj, "percent")):
            return "lens"
        return "other"

    def load_optical(
        self,
        assembly,
        runtime_targets=None,
        category: str = "all",
        select_first: bool = True,
    ) -> None:
        self.clear()
        self.setHeaderLabel("Optical calculation components")
        targets = runtime_targets or {}
        module_paths = self._module_paths(assembly)
        module_types = {
            module.key: module.type for module in assembly.modules
        }
        grouped = {name: [] for name in OPTICAL_CATEGORY_ORDER}
        for part in assembly.parts:
            if not self._is_optical_part(part, targets):
                continue
            part_category = self.optical_category(
                part,
                targets.get(part.key),
                module_type=module_types.get(part.module_key),
            )
            if category not in {"all", part_category}:
                continue
            grouped[part_category].append(part)

        if category == "all":
            controls = [
                targets[key]
                for key in GLOBAL_RUNTIME_KEYS
                if key in targets
            ]
        else:
            controls = []
        if controls:
            root = QTreeWidgetItem([f"Global controls ({len(controls)})"])
            self.addTopLevelItem(root)
            for target in controls:
                root.addChild(self._selection_item(
                    target.label,
                    TreeSelection(target.key, target.label, None),
                ))

        for part_category in OPTICAL_CATEGORY_ORDER:
            parts = grouped[part_category]
            source_control = (
                targets.get(ELECTRON_SOURCE_RUNTIME_KEY)
                if part_category == "electron_source"
                and category in {"all", "electron_source"}
                else None
            )
            item_count = len(parts) + int(source_control is not None)
            if not item_count:
                continue
            label = OPTICAL_CATEGORY_LABELS[part_category]
            root = QTreeWidgetItem([f"{label} ({item_count})"])
            root.setData(0, Qt.ItemDataRole.UserRole + 1, part_category)
            self.addTopLevelItem(root)
            if source_control is not None:
                source_item = self._selection_item(
                    ELECTRON_SOURCE_RUNTIME_LABEL,
                    TreeSelection(
                        source_control.key,
                        ELECTRON_SOURCE_RUNTIME_LABEL,
                        None,
                    ),
                )
                source_item.setToolTip(
                    0,
                    "Numerical ray-tracing settings for the selected gun",
                )
                root.addChild(source_item)
            for part in parts:
                item = self._selection_item(
                    (f"{part.name} (always inserted)"
                     if part.key in FIXED_APERTURE_KEYS else part.name),
                    TreeSelection(
                        part.key,
                        part.name,
                        module_paths[part.module_key],
                    ),
                )
                if part.data.get("blanking_role") == "standard_pre_specimen":
                    item.setToolTip(
                        0, f"{part.key}\nExisting gun tilt coils also provide "
                        "standard pre-specimen beam blanking. "
                        "No additional column module is required."
                    )
                root.addChild(item)

        self._finish_load(select_first)

    def load_mechanical(
        self, assembly, runtime_targets=None, select_first: bool = False
    ) -> None:
        self.clear()
        self.setHeaderLabel("Mechanical layout components")
        targets = runtime_targets or {}
        selected_paths = dict(assembly.selected_module_paths)
        module_paths = self._module_paths(assembly)

        manifest_root = QTreeWidgetItem(["Module manifests"])
        self.addTopLevelItem(manifest_root)
        for module in assembly.modules:
            module_path = selected_paths[module.type]
            manifest_root.addChild(self._selection_item(
                module.key,
                TreeSelection(
                    f"@module:{module.type}",
                    module.key,
                    module_path,
                    is_module=True,
                ),
            ))

        for module in assembly.modules:
            parts = [
                part
                for part in assembly.parts
                if part.module_key == module.key
                and part.key not in CENTRAL_WORKSPACE_KEYS
                and part.key not in ENERGY_FILTER_INTERNAL_KEYS
                and not self._is_optical_part(part, targets)
            ]
            if not parts:
                continue
            root = QTreeWidgetItem([f"{module.key} ({len(parts)})"])
            self.addTopLevelItem(root)
            for part in parts:
                root.addChild(self._selection_item(
                    part.name,
                    TreeSelection(
                        part.key,
                        part.name,
                        module_paths[part.module_key],
                    ),
                ))

        self._finish_load(select_first)

    def _finish_load(self, select_first: bool) -> None:
        self.expandToDepth(0)
        if select_first:
            self.select_first()

    def select_first(self) -> bool:
        pending = [
            self.topLevelItem(index)
            for index in range(self.topLevelItemCount())
        ]
        while pending:
            item = pending.pop(0)
            selection = item.data(0, Qt.ItemDataRole.UserRole)
            if isinstance(selection, TreeSelection):
                self.setCurrentItem(item)
                return True
            pending.extend(
                item.child(index) for index in range(item.childCount())
            )
        return False

    def current_key(self) -> str | None:
        current = self.currentItem()
        if current is None:
            return None
        selection = current.data(0, Qt.ItemDataRole.UserRole)
        return selection.key if isinstance(selection, TreeSelection) else None

    def _emit_current_item(self, current, _previous) -> None:
        if current is None:
            return
        selection = current.data(0, Qt.ItemDataRole.UserRole)
        if isinstance(selection, TreeSelection):
            self.component_selected.emit(selection)

    def _emit_activated_item(self, item, _column: int) -> None:
        """Emit an explicit navigation request for a double-clickable leaf."""

        if item is None:
            return
        selection = item.data(0, Qt.ItemDataRole.UserRole)
        if isinstance(selection, TreeSelection):
            self.component_activated.emit(selection)

    def select_key(self, key: str) -> bool:
        """Select a component by canonical key for plot-to-tree linking."""

        pending = [
            self.topLevelItem(index)
            for index in range(self.topLevelItemCount())
        ]
        while pending:
            item = pending.pop(0)
            selection = item.data(0, Qt.ItemDataRole.UserRole)
            if isinstance(selection, TreeSelection) and selection.key == key:
                self.setCurrentItem(item)
                self.scrollToItem(item)
                return True
            pending.extend(
                item.child(index) for index in range(item.childCount())
            )
        return False
