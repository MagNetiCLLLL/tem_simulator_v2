"""Projector Lens P1 anchored to the Diffraction Lens."""

from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar

from temsim import module_manifest
from temsim.component_keys import (
    PROJECTOR_LENS_1,
    SELECTED_AREA_APERTURE,
    canonical_lens_key,
)
from temsim.optics.selected_area_downstream import downstream_offset_mm
from temsim.optics.model import Gaussian
from temsim.optics.selected_area_aperture import (
    SELECTED_AREA_APERTURE_DEFINITION,
)
from temsim.optics.round_lens import (
    AnchoredRoundLensComponent,
    AnchoredRoundLensGeometry,
    restore_anchored_round_lens,
)

_DEFAULT_MANIFEST_PART = module_manifest.part_data(
    "project_and_recording_system/EnergyFilter.toml",
    PROJECTOR_LENS_1,
)


@dataclass(frozen=True)
class ProjectorLensP1Definition:
    key: str = PROJECTOR_LENS_1
    label: str = "Projector Lens P1"
    anchor_key: str = SELECTED_AREA_APERTURE
    mechanical_center_downstream_of_anchor_mm: float = downstream_offset_mm(
        PROJECTOR_LENS_1
    )
    optical_reference_downstream_of_anchor_mm: float = downstream_offset_mm(
        PROJECTOR_LENS_1
    )
    # Mechanical defaults come from the authoritative recording-system TOML.
    mechanical_length_mm: float = float(_DEFAULT_MANIFEST_PART["length_mm"])
    mechanical_outer_diameter_mm: float = float(
        _DEFAULT_MANIFEST_PART["mechanical_outer_diameter_mm"]
    )
    mechanical_clear_bore_diameter_mm: float = float(
        _DEFAULT_MANIFEST_PART["mechanical_clear_bore_diameter_mm"]
    )
    pole_gap_mm: float = float(_DEFAULT_MANIFEST_PART["pole_gap_mm"])
    b0_t: float = float(_DEFAULT_MANIFEST_PART["maximum_peak_field_t"])
    a_mm: float = float(_DEFAULT_MANIFEST_PART["field_half_width_mm"])
    percent: float = float(_DEFAULT_MANIFEST_PART["default_excitation_percent"])
    maximum_percent: float = float(
        _DEFAULT_MANIFEST_PART["maximum_excitation_percent"]
    )
    colour: str = "#795548"
    owner: str = "projector"
    kind: str = "round_lens"
    shape_profile: str = "magnetic_lens_yoke"
    interaction_kind: str = "axial_magnetic_field"

    @property
    def name(self):
        return self.label

    @property
    def effective_aperture_radius_mm(self):
        return self.mechanical_clear_bore_diameter_mm / 2.0

    def geometry_for(self, anchor_geometry):
        return AnchoredRoundLensGeometry(
            mechanical_center_below_sample_mm=(
                float(anchor_geometry.mechanical_center_below_sample_mm)
                + self.mechanical_center_downstream_of_anchor_mm
            ),
            mechanical_length_mm=self.mechanical_length_mm,
            mechanical_outer_diameter_mm=(
                self.mechanical_outer_diameter_mm
            ),
            mechanical_clear_bore_diameter_mm=(
                self.mechanical_clear_bore_diameter_mm
            ),
            pole_gap_mm=self.pole_gap_mm,
            optical_reference_z_mm=(
                float(anchor_geometry.optical_reference_z_mm)
                + self.mechanical_center_downstream_of_anchor_mm
            ),
        )

    def create_component(self):
        return ProjectorLensP1Component(
            name=self.label,
            key=self.key,
            z_mm=(
                SELECTED_AREA_APERTURE_DEFINITION
                .standalone_optical_reference_z_mm
                + self.mechanical_center_downstream_of_anchor_mm
            ),
            b0_t=self.b0_t,
            a_mm=self.a_mm,
            percent=self.percent,
            max_percent=self.maximum_percent,
            colour=self.colour,
            gaussian=[Gaussian(*term) for term in _DEFAULT_MANIFEST_PART[
                "field_profile_terms"
            ]],
            enabled=True,
            cs_mm=None,
            cc_mm=None,
            polarity=int(_DEFAULT_MANIFEST_PART["field_polarity"]),
            normalise_profile_peak=False,
            anchor_key=self.anchor_key,
            mechanical_center_downstream_of_anchor_mm=(
                self.mechanical_center_downstream_of_anchor_mm
            ),
            optical_reference_downstream_of_anchor_mm=(
                self.optical_reference_downstream_of_anchor_mm
            ),
            mechanical_length_mm=self.mechanical_length_mm,
            mechanical_outer_diameter_mm=(
                self.mechanical_outer_diameter_mm
            ),
            mechanical_clear_bore_diameter_mm=(
                self.mechanical_clear_bore_diameter_mm
            ),
            pole_gap_mm=self.pole_gap_mm,
            corrector=self.owner,
        )


@dataclass
class ProjectorLensP1Component(AnchoredRoundLensComponent):
    EXPECTED_KEY: ClassVar[str] = PROJECTOR_LENS_1
    EXPECTED_ANCHOR_KEY: ClassVar[str] = SELECTED_AREA_APERTURE


PROJECTOR_LENS_P1_DEFINITION = ProjectorLensP1Definition()


def create_projector_lens_p1():
    component = PROJECTOR_LENS_P1_DEFINITION.create_component().validate()
    component.field_calibration_status = str(
        _DEFAULT_MANIFEST_PART["field_calibration_status"]
    )
    component.field_calibration_source = str(
        _DEFAULT_MANIFEST_PART["field_calibration_source"]
    )
    return component


def projector_lens_p1_from_dict(
    data,
    legacy_anchor_reference_z_mm=None,
    legacy_reference_z_mm=None,
):
    values = dict(data)
    values["key"] = canonical_lens_key(values.get("key", ""))
    if (
        "optical_reference_downstream_of_anchor_mm" not in values
        and legacy_reference_z_mm is not None
    ):
        values["z_mm"] = float(legacy_reference_z_mm)
    component = restore_anchored_round_lens(
        create_projector_lens_p1(),
        values,
        legacy_anchor_reference_z_mm=legacy_anchor_reference_z_mm,
    )
    component.key = PROJECTOR_LENS_1
    component.name = PROJECTOR_LENS_P1_DEFINITION.label
    component.anchor_key = SELECTED_AREA_APERTURE
    if values.get("anchor_key") != SELECTED_AREA_APERTURE:
        offset = downstream_offset_mm(PROJECTOR_LENS_1)
        component.mechanical_center_downstream_of_anchor_mm = offset
        component.optical_reference_downstream_of_anchor_mm = offset
    component.corrector = PROJECTOR_LENS_P1_DEFINITION.owner
    return component.validate()
